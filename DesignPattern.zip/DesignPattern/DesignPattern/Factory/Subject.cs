using System;

namespace DesignPattern
{
    public interface Subject
    {
        void addSubject(string subjectName);
    }
}
