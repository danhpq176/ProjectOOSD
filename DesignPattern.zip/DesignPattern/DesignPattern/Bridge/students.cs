using System;

namespace DesignPattern
{
    public class StudentNotification : Notification
    {
        public void addNotification()
        {
            Console.WriteLine("Student adding notification!");
        }
    }
}
