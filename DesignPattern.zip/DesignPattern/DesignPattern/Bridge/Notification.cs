using System;

namespace DesignPattern
{
    public interface Notification
    {
        void addNotification();

    }
}
